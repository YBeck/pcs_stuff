<?php

echo file_get_contents("https://www.google.com");
?>