/*global $, pcs*/
(function () {
    "use strict";

    var contactTable = $("#contactTable tbody"),
        contacts = [];

    function addContact(contact) {
        contacts.push(contact);

        if (contacts.length === 1) {
            contactTable.empty();
        }

        var theRow = $('<tr>' +
            '<td>' + contact.firstName + '</td>' +
            '<td>' + contact.lastName + '</td>' +
            '<td>' + contact.email + '</td>' +
            '<td>' + contact.phone + '</td>' +
            '<td><button>delete</button></td>' +
            '</tr>'
        ).appendTo(contactTable);
        theRow.find('button')
            .click(function () {
                $.post("deleteContact.php", { id: contact.Id }, function () {
                    theRow.remove();
                }).fail(function (jqxhr) {
                    pcs.messagebox.show("Error: " + jqxhr.responseText);
                });
            });
    }

    var firstNameInput = $("#first");
    var lastNameInput = $("#last");
    var emailInput = $("#email");
    var phoneInput = $("#phone");
    var addContactForm = $("#addContactForm");

    function hideAddContactForm() {
        addContactForm.slideUp();
        addContactForm[0].reset();
    }

    addContactForm.on("submit", function (event) {
        var newContact = {
            firstName: firstNameInput.val(),
            lastName: lastNameInput.val(),
            email: emailInput.val(),
            phone: phoneInput.val()
        };
        $.post("addContact.php", newContact, function () {
            addContact(newContact);
            hideAddContactForm();
        }).fail(function (jqxhr) {
            pcs.messagebox.show("Error: " + jqxhr.responseText);
        });

        event.preventDefault();
    });

    $("#cancel").click(hideAddContactForm);

    $("#add").click(function () {
        addContactForm.slideDown();
    });

    $("#load").click(function () {
        $.get("getContacts.php", function (loadedContactData) {
            var loadedContacts = JSON.parse(loadedContactData);
            loadedContacts.forEach(addContact);
        })
        /*$.get("contacts.data", function (loadedContacts) {
            loadedContacts.forEach(addContact);
        }, 'json')*/
        /*$.get("contacts.json", function (loadedContacts) {
            loadedContacts.forEach(addContact);
        })*/
        /*$.getJSON("contacts.data", function (loadedContacts) {
            loadedContacts.forEach(addContact);
        })*/.fail(function (jqxhr) {
                pcs.messagebox.show("Error: " + jqxhr.responseText);
            });
    });
}());