<?php
$president = "Donald";
echo '{"name":"' . $president . '"}';
