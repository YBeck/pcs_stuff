console.log(x);
console.log(y);

var x = null;
console.log(x);
var y;
console.log(y);

console.log(x === y);
console.log(x == y);

if (x === undefined || x === null) {

}

if (x == null) {

}

if (x == undefined) {

}

console.log(z);